A Little Jar of Love for Memo

Publish:
1. Create a new GitHub repository (e.g. memo-love-jar).
2. Upload index.html to the repository root and commit.
3. Open Settings → Pages.
4. Choose Deploy from a branch, branch main, folder /(root), then Save.
5. Wait for the Visit site link.

Edit the 30 notes in the reasons array near the bottom of index.html.
